import { type ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Spinner } from './ui';

export default function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner label="جارٍ التحقق من الجلسة..." />;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}